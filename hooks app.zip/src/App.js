import "./App.css";
import DataFetching from "./datafetching";

function App() {
  return (
    <>
      <DataFetching />
    </>
  );
}

export default App;
